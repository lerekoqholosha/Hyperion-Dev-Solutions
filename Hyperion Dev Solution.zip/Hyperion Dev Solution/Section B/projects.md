## Section B Solution
**Project1 :**
- Link_1:https://github.com/lerekoqholosha/Zindi-Challenge

**Project2 :**
- Link_2: https://github.com/lerekoqholosha/BrandHubb-Model
