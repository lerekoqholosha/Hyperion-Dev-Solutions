class Solution:
    def groupAnagrams(self, strs):
        """
        Given a list of strings, groups the anagrams together.

        An Anagram is a word or phrase formed by rearranging the letters of a different
        word or phrase, typically using all the original letters exactly once.

        Args:
            strs: A list of strings.

        Returns:
            A list of lists, where each inner list contains a group of anagrams.

        Raises:
            TypeError: If strs is not a list of strings.
        """
        if not all(isinstance(s, str) for s in strs):
            raise TypeError("Input must be a list of strings.")
        
        result = {}
        for s in strs:
            sorted_str = "".join(sorted(s))
            if sorted_str in result:
                result[sorted_str].append(s)
            else:
                result[sorted_str] = [s]
        
        return list(result.values())


ob1 = Solution()
print(ob1.groupAnagrams(["eat", "tea", "tan", "ate", "nat", "bat"]))

