
## Solution Link
- link:https://edabit.com/challenge/im47j9ax22Z5MgqvW

## Worst-case space complexity analysis

- The space complexity of the sayNumber function is proportional to the size of the input number. We can divide the worst-case space complexity into three parts:

- Memory required to store the input number as a string. This requires at most 15 bytes (for 15 digit input).

- Memory required to store the list of words constructed from the input number. In the worst case, this list could contain all words required for the largest input number (999,999,999,999,999), which would be approximately 80