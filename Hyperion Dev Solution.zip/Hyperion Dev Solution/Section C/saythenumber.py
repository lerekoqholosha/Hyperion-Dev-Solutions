#importing the the tesing library
import unittest

words1 = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
          'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen']
words2 = ['twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety']
words3 = ['trillion', 'billion', 'million', 'thousand', 'hundred']

def stn(num):
    rem, say = num, ''
    for i, exp in enumerate([12, 9, 6, 3, 2]):
        q, rem = divmod(rem, 10**exp)
        if q > 0:
            if say: say += ', '
            say += stn(q) + ' ' + words3[i]
    if say and rem: say += ' and '
    if rem < 20:
        if rem: say += words1[rem]
    else: 
        q, rem = divmod(rem-20, 10)
        say += words2[q]
        if rem: say += '-' + stn(rem)
    return say

def say_the_number(num):
    if num == 0:
        return 'Zero.'
    say = stn(num)
    return say[0].upper() + say[1:] + '.'



class TestSayNumber(unittest.TestCase):
    def test_zero(self):
        self.assertEqual(say_the_number(0), "Zero.")
    
    def test_single_digit(self):
        self.assertEqual(say_the_number(3), "Three.")
    
    def test_two_digits(self):
        self.assertEqual(say_the_number(11), "Eleven.")
        self.assertEqual(say_the_number(99), "Ninety nine.")
    
    def test_three_digits(self):
        self.assertEqual(say_the_number(123), "One hundred and twenty three.")
        self.assertEqual(say_the_number(900), "Nine hundred.")
        self.assertEqual(say_the_number(909), "Nine hundred and nine.")
    
    def test_large_numbers(self):
        self.assertEqual(say_the_number(1043283), "One million, forty three thousand, two hundred and eighty three.")
        self.assertEqual(say_the_number(90376000010012), "Ninety trillion, three hundred and seventy six billion, ten thousand and twelve.")
        self.assertEqual(say_the_number(123456789012345), "One hundred and twenty three trillion, four hundred and fifty six billion, seven hundred and eighty nine million, twelve thousand and three hundred and forty five.")
        self.assertEqual(say_the_number(999999999999999), "Nine hundred and ninety nine trillion, nine hundred and ninety nine billion, nine hundred and ninety nine million, nine hundred and ninety nine thousand and nine hundred and ninety nine.")
    
    
